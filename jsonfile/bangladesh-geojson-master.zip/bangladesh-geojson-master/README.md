# Bangladesh GEOJSON

### Divisions
* Division name in English
* Division name in Bangla
* Division Latitude and Longitude

### Districts
* District mapped with Divisions
* District name in English
* District name in Bangla
* District Latitude and Longitude

### Upazilas
* Upazila mapped with Districts
* Upazila name in Bangla
* Upazila name in English
* Upazila Latitude and Longitude

### Post Office and Post Code
* Post Office
* Post Code
